<?php 

	$host = "localhost";
	$username = "root";
	$password = "";
	$database = "db_perum";

	$conn = new mysqli($host, $username, $password, $database);

?>