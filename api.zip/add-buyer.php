<?php
	
	require 'connection.php';

	$unit = $_POST['unit'];
	$houseId = $_POST['house_id'];
	$nama = $_POST['nama'];
	$no_telp = $_POST['no_telp'];
	$no_pasangan = $_POST['no_pasangan'];
	$no_darurat = $_POST['no_darurat'];
	$alamat = $_POST['alamat'];
	$pekerjaan = $_POST['pekerjaan'];
	$status_berkas = $_POST['status_berkas'];
	$tgl_booking = $_POST['tgl_booking'];
	$bank_pel = $_POST['bank_pel'];
	$ket = $_POST['ket'];
	$a = $_POST['a'];
	$b = $_POST['b'];
	$c = $_POST['c'];
	$d = $_POST['d'];
	$e = $_POST['e'];
	$f = $_POST['f'];
	$g = $_POST['g'];
	// $bayarfee = $_POST['bayarfee'];
	// $bayar1 = $_POST['bayar1'];
	// $bayar2 = $_POST['bayar2'];
	// $bayar3 = $_POST['bayar3'];
	// $bayar4 = $_POST['bayar4'];
	// $total_pembayaran = $_POST['total_pembayaran'];
	$verified = $_POST['verified'];

	$sql = "INSERT INTO tb_buyer (unit, house_id, nama, no_telp, no_pasangan, no_darurat, alamat, pekerjaan, status_berkas, tgl_booking, bank_pel, ket, a, b, c, d, e, f, g, verified) VALUES
	('$unit', '$houseId', '$nama', '$no_telp', '$no_pasangan', '$no_darurat', '$alamat', '$pekerjaan', '$status_berkas', '$tgl_booking', '$bank_pel', '$ket', '$a', '$b', '$c', '$d', '$e', '$f', '$g', '$verified')";

	if ($conn->query($sql)) {
		$data = array('status'=>'berhasil');
		echo json_encode($data);
	} else {
		echo $conn->error;
	}
	
?>