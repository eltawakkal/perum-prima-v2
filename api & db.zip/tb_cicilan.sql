-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 13 Apr 2020 pada 08.20
-- Versi server: 10.3.16-MariaDB
-- Versi PHP: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perum`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_cicilan`
--

CREATE TABLE `tb_cicilan` (
  `id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `house_id` int(11) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `cicilan` bigint(20) NOT NULL,
  `type` varchar(100) NOT NULL,
  `trans_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_cicilan`
--

INSERT INTO `tb_cicilan` (`id`, `buyer_id`, `house_id`, `unit`, `cicilan`, `type`, `trans_date`) VALUES
(28, 356, 1, 'F-14', 2500000, 'Booking Fee', '2020-03-23'),
(29, 356, 1, 'F-14', 1000000, 'Cicilan Ke 1', '2020-04-06'),
(31, 359, 1, 'F-05', 3000000, 'Booking Fee', '2020-02-08');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_cicilan`
--
ALTER TABLE `tb_cicilan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_cicilan`
--
ALTER TABLE `tb_cicilan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
