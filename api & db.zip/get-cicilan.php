<?php
	
	require 'connection.php';

	$buyerId = $_POST['buyer_id'];
	$houseId = $_POST['house_id'];
	$unit = $_POST['unit'];

	$sql = "SELECT * FROM tb_cicilan WHERE buyer_id = $buyerId AND house_id = $houseId AND unit = '$unit'";
	$result = $conn->query($sql);

	$data = array();
	$fixData = array();
	$status = '1';
	$totalCicilanInRupiah = 0;
	$totalCicilan =0;

	if ($result != null) {

		while ($row = $result->fetch_assoc()) {
			$data[] = $row;
		}

		for ($i=0; $i < count($data); $i++) {

			$totalCicilan += $data[$i]['cicilan'];

			// if ($i == 0) {
			// 	$title = 'Booking Fee';
			// } else {
			// 	$title = 'Cicilan Ke ' . $i;
			// }

			if ($i > 0) {
				$date1 = date_create($data[$i-1]['trans_date']);
				$date2 = date_create($data[$i]['trans_date']);
				$diff = date_diff($date1,$date2);
				$hari = $diff->days;

				if ($i == 1) {
					if ($hari <= 14) {
						$status = '1';
					} else if ($hari > 14) {
						$status = '0';
					}
				} else if ($i > 1) {
					if ($hari <= 30) {
						$status = '1';
					} else if ($hari > 30) {
						$status = '0';
					}
				}
			}

			$rupiah = "Rp " . number_format($data[$i]['cicilan'],0,',','.');

			array_push($fixData,
				array(
					'id' => $data[$i]['id'],
					'type' => $data[$i]['type'],
					'cicilan' => $rupiah,
					'date' => $data[$i]['trans_date'],
					'status' => $status
				)
			);
		}

		$totalCicilanInRupiah = "Rp " . number_format($totalCicilan,0,',','.');

	}

	$finalData = array();

	array_push($finalData, array('total_cicilan' => $totalCicilanInRupiah, 'data' => $fixData));

	echo json_encode($finalData);

?>